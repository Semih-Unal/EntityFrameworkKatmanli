﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_KatmanliMimari.DTO
{
    public class YazarDTO
    {
        // 3. Form1den geldim
        public int YazarID { get; set; }
        public string YazarAd { get; set; }
        public string YazarSoyad { get; set; }
        public string Ozgecmis { get; set; }
        //---------------------------
        public override string ToString()
        {
            return this.YazarAd + " " + this.YazarSoyad;
        }
        // .DTO içine bir de "YazarDataSourceDTO.cs" ckassı ekliyorum ... ordayım
    }
}
