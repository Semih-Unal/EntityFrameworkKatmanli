﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_KatmanliMimari.DTO
{
    // 4. YazarDTO.cs'den geldim
    public class YazarDataSourceDTO
    {
        public int YazarID { get; set; }
        public string AdiSoyadi { get; set; }
        //---------------
        public override string ToString()
        {
            return this.AdiSoyadi;
        }
        // .BLL içine -> "YazarRepository.cs" adında class açıyorum oradayım
    }
}
