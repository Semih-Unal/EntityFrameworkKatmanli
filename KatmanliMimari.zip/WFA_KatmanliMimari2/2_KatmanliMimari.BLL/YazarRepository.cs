﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//---------------------------
using System.Data.Entity;
using _1_KatmanliMimari.DAL;
using _3_KatmanliMimari.DTO;

namespace _2_KatmanliMimari.BLL
{
    // 5. YazarDataSourceDTO.cs'den geldim ...
    public class YazarRepository // yazar sağlayıcımız ...
    {
        // .BLL içine .DTO ve .DAL referanslarını ekleyip çekiyoruz

        static KutuphaneDBEntities db = new KutuphaneDBEntities();

        public static List<YazarDataSourceDTO> dataSourceTumYazarlar()
        {
            var sonuc = db.Yazarlars.Select
                (
                    y => new YazarDataSourceDTO
                    {
                        YazarID= y.YazarID,
                        AdiSoyadi = y.YazarAd + " " + y.YazarSoyad
                    }
                ).ToList();
            return (List<YazarDataSourceDTO>)sonuc;
        }
        public static List<YazarDTO> tumYazarlar()
        {
            var sonuc = db.Yazarlars.Select
                (
                    y => new YazarDTO
                    {
                        YazarID = y.YazarID,
                        YazarAd = y.YazarAd,
                        YazarSoyad = y.YazarSoyad,
                        Ozgecmis=y.Ozgecmis
                    }
                ).ToList();
            return (List<YazarDTO>)sonuc;
        }
        //----------------------------------------------
        // AnaForm için Insert / Update / Delete ve List işlemlerine bakalım ...
        // Insert Tanımlamamız ...
        public static bool YazarEkleme(YazarDTO gelenYazar)
        {
            bool sonuc = false;

            Yazarlar yeniYazar = new Yazarlar();

            yeniYazar.YazarAd = gelenYazar.YazarAd;
            yeniYazar.YazarSoyad = gelenYazar.YazarSoyad;
            yeniYazar.Ozgecmis = gelenYazar.Ozgecmis;

            db.Yazarlars.Add(yeniYazar);
            sonuc = db.SaveChanges() > 0; // Yapılan değişiklikleri kaydet

            return sonuc; // güncelleme olduğunda true döncek
        }
        // Not : veya bu yapıyı ek bir class üzerinden de alabilirsiniz ... -> .BLL içine ayrı classlar olarak -> "YazarEkle.cs" vb. de oluşturabilirsiniz ... bir bakalım ...
        // .BLL - YazarEkle.cs'deyin

        //--------------------------
        // 7. YazarEkle.cs'den tekrar geldim ...
        //------------------------------

        // List(select) tanımlamamız > ID'ye göre arama için bakalım ..
        public static YazarDTO IDyeGoreYazarGetir(int yazarID)
        {
            // .DTO içindeki ...
            Yazarlar y = db.Yazarlars.Find(yazarID); // primaryKey id'ye göre Find ile arama yapacak ...

            YazarDTO yDTO = new YazarDTO()
            {
                YazarID = y.YazarID,
                YazarAd = y.YazarAd,
                YazarSoyad = y.YazarSoyad,
                Ozgecmis = y.Ozgecmis
            };
            return yDTO;
        }
        
        // Update Tanımlamamız ...
        public static bool YazarGuncelle(YazarDTO gelenYazar)
        {
            bool sonuc = false;

            Yazarlar guncellenecekYazar = db.Yazarlars.Find(gelenYazar.YazarID);

            guncellenecekYazar.YazarAd = gelenYazar.YazarAd;
            guncellenecekYazar.YazarSoyad = gelenYazar.YazarSoyad;
            guncellenecekYazar.Ozgecmis = gelenYazar.Ozgecmis;

            sonuc = db.SaveChanges() > 0; // Yapılan değişiklikleri kaydet

            return sonuc; // güncelleme olduğunda true döncek
        }

        // Delete Tanımlamamız ...
        public static bool YazarSilme(YazarDTO gelenYazar)
        {

            Yazarlar silinecekYazar = db.Yazarlars.Where(y=>y.YazarID == gelenYazar.YazarID).FirstOrDefault();

            db.Yazarlars.Remove(silinecekYazar);
           

            return db.SaveChanges() > 0; 
        }
    }

}
