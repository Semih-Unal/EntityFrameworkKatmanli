﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//------------
using _1_KatmanliMimari.DAL;
using _2_KatmanliMimari.BLL;
using _3_KatmanliMimari.DTO;

namespace _2_KatmanliMimari.BLL
{
    // 6. YazarRepository.cs'den geldim...
    public class YazarEkle
    {
        public static void YazarAdd(Yazarlar yazar)
        {
            using(KutuphaneDBEntities db = new KutuphaneDBEntities())
            {
                db.Yazarlars.Add(yazar);
                db.SaveChanges();
            }
        }
    }

    // tekrara YazarRepository.cs ye dönüyorum ...
}
