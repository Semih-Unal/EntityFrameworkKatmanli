﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//-------------------------------
// referanları ekleyip .. + EF dosyalarını ekliyorum + AppConfig içine .DAL AppConfig içini kopyaladım
using _1_KatmanliMimari.DAL; // MVC'deki > Model kısmına denk geliyor ...
using _2_KatmanliMimari.BLL; // MVC'deki > Controller kısmına denk geliyor ...
using _3_KatmanliMimari.DTO;

namespace _4_KatmanliMimari.UI
{
    // 2. 3_KatmanliMimari.DTO (Data Transfer Object) -> Katmanının Amacı : DB'de tanımlanan tüm nesneleri taşımak yani transfer etmek .. (iki yönlüdür) içinde
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // 8. "YazarRepository.cs" 'den Geldim ...
        KutuphaneDBEntities db = new KutuphaneDBEntities();

        private void Form1_Load(object sender, EventArgs e)
        {
            YazarlarıGetir();
        }

        private void YazarlarıGetir()
        {

            cbYazarlar.DataSource = db.Yazarlars.Select(y => new
            {
                y.YazarID,
                //y.YazarAd,
                //y.YazarSoyad,
                YazarAdiSoyadi = y.YazarAd + " " + y.YazarSoyad
            }).ToList();

            cbYazarlar.DisplayMember = "YazarAdiSoyadi";
            cbYazarlar.ValueMember = "YazarID";
        }

        private void cbYazarlar_SelectionChangeCommitted(object sender, EventArgs e)
        {
            int yazarID = (int)cbYazarlar.SelectedValue;
            KitaplariGetir(yazarID);

            toolStripStatusLabelAdet.Text = lstKitaplar.Items.Count.ToString() + " adet kitap listelenmiştir...";
        }

        private void KitaplariGetir(int id)
        {

            lstKitaplar.DataSource = db.Kitaplars.Where(k => k.YazarId == id).Select(k=> new
            {
                k.KitapID,
                k.KitapAdi
            }).ToList();
            lstKitaplar.DisplayMember = "KitapAdi";
            lstKitaplar.ValueMember = "KitapID";
        }

        #region Yazar Yavru Formlarımız
        private void ekleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Yazar.frmYazarEkle ye = new Yazar.frmYazarEkle();
            
            ye.Show();

            this.Hide();
        }

        private void güncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Yazar.frmYazarGuncelle yg = new Yazar.frmYazarGuncelle();
            yg.Show();

            this.Hide();
        }

        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Yazar.frmYazarSil ys = new Yazar.frmYazarSil();
            ys.Show();

            this.Hide();
        }
        #endregion

        #region Kitap Yavru Formlarımız
        private void ekleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Kitap.frmKitapEkle ke = new Kitap.frmKitapEkle();
            ke.Show();

            this.Hide();
        }

        private void güncelleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Kitap.frmKitapGuncelle kg = new Kitap.frmKitapGuncelle();
            kg.Show();

            this.Hide();
        }

        private void silToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Kitap.frmKitapSil ks = new Kitap.frmKitapSil();
            ks.Show();

            this.Hide();
        } 
        #endregion
    }
}
