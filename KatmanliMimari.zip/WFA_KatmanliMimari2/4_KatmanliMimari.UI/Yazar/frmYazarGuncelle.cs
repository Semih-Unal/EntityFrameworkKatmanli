﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//-------------------------------

using _1_KatmanliMimari.DAL; 
using _2_KatmanliMimari.BLL; 
using _3_KatmanliMimari.DTO;

namespace _4_KatmanliMimari.UI.Yazar
{
    public partial class frmYazarGuncelle : Form
    {
        public frmYazarGuncelle()
        {
            InitializeComponent();
        }

        private void frmYazarGuncelle_Load(object sender, EventArgs e)
        {
            cbGuncelYazarAdi.DataSource = YazarRepository.tumYazarlar();
            cbGuncelYazarAdi.DisplayMember = "YazarAd";
            cbGuncelYazarAdi.ValueMember = "YazarID";
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            YazarDTO secilenYazar = cbGuncelYazarAdi.SelectedItem as YazarDTO;

            YazarDTO guncelYazar = new YazarDTO()
            {
                YazarID = Convert.ToInt32(txtGuncelYazarId.Text),
                YazarAd = secilenYazar.YazarAd,
                YazarSoyad = txtGuncelYazarSoyadi.Text,
                Ozgecmis = txtGuncelOzgecmis.Text
            };
            YazarRepository.YazarGuncelle(guncelYazar);

            MessageBox.Show("Yazar Güncelleme İşlemi Başarıyla Gerçekleşmiştir ...");
            Form1 frm = new Form1();
            this.Close();
            frm.Show();
        }

        private void cbGuncelYazarAdi_SelectionChangeCommitted(object sender, EventArgs e)
        {
            YazarDTO secilenYazar = cbGuncelYazarAdi.SelectedItem as YazarDTO;
            txtGuncelYazarId.Text = secilenYazar.YazarID.ToString();
            txtGuncelYazarSoyadi.Text = secilenYazar.YazarSoyad;
            txtGuncelOzgecmis.Text = secilenYazar.Ozgecmis;
        }

        private void Temizle()
        {
            txtGuncelYazarId.Clear();
            txtGuncelYazarSoyadi.Clear();
            txtGuncelOzgecmis.Clear();

            cbGuncelYazarAdi.SelectedIndex = -1;
            txtGuncelYazarSoyadi.Focus();
        }
    }
}
