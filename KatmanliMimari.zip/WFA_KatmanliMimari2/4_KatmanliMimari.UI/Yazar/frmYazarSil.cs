﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//------------------
using _1_KatmanliMimari.DAL;
using _2_KatmanliMimari.BLL;
using _3_KatmanliMimari.DTO;

namespace _4_KatmanliMimari.UI.Yazar
{
    public partial class frmYazarSil : Form
    {
        public frmYazarSil()
        {
            InitializeComponent();
        }

        private void frmYazarSil_Load(object sender, EventArgs e)
        {
            yazarListele(); // metodu altta ...
        }

        private void yazarListele()
        {
            List<YazarDTO> yazarListele = YazarRepository.tumYazarlar();

            foreach (YazarDTO yl in yazarListele)
            {
                ListViewItem li = new ListViewItem();

                li.Tag = yl;
                li.Text = yl.YazarID.ToString();
                li.SubItems.Add(yl.YazarAd);
                li.SubItems.Add(yl.YazarSoyad);
                li.SubItems.Add(yl.Ozgecmis);

                lstwYazarlar.Items.Add(li);
            }
        }

        private void btnYazarSil_Click(object sender, EventArgs e)
        {
            if (lstwYazarlar.SelectedItems.Count > 0)
            {
                YazarDTO secilenYazar = (YazarDTO)lstwYazarlar.SelectedItems[0].Tag;

                YazarRepository.YazarSilme(secilenYazar);

                MessageBox.Show("Yazar Silme İşleminiz Başarı İle Gerçekleşmiştir...");
            }
            else
            {
                MessageBox.Show("Lütfen Silmek İstediğiniz Yazarı Seçiniz !!!");
            }

            Form1 frm = new Form1();
            this.Close();
            frm.Show();
        }
    }
}
