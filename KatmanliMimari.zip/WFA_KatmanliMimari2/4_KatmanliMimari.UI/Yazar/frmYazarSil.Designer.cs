﻿namespace _4_KatmanliMimari.UI.Yazar
{
    partial class frmYazarSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstwYazarlar = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnYazarSil = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstwYazarlar
            // 
            this.lstwYazarlar.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lstwYazarlar.Dock = System.Windows.Forms.DockStyle.Top;
            this.lstwYazarlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstwYazarlar.FullRowSelect = true;
            this.lstwYazarlar.GridLines = true;
            this.lstwYazarlar.Location = new System.Drawing.Point(0, 0);
            this.lstwYazarlar.Name = "lstwYazarlar";
            this.lstwYazarlar.Size = new System.Drawing.Size(492, 300);
            this.lstwYazarlar.TabIndex = 0;
            this.lstwYazarlar.UseCompatibleStateImageBehavior = false;
            this.lstwYazarlar.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Yazar ID";
            this.columnHeader1.Width = 98;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Yazar Ad";
            this.columnHeader2.Width = 111;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Yazar Soyad";
            this.columnHeader3.Width = 115;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Yazar Özgeçmiş";
            this.columnHeader4.Width = 146;
            // 
            // btnYazarSil
            // 
            this.btnYazarSil.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnYazarSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYazarSil.Location = new System.Drawing.Point(0, 298);
            this.btnYazarSil.Name = "btnYazarSil";
            this.btnYazarSil.Size = new System.Drawing.Size(492, 44);
            this.btnYazarSil.TabIndex = 1;
            this.btnYazarSil.Text = "Seçilen Yazarları Sil";
            this.btnYazarSil.UseVisualStyleBackColor = true;
            this.btnYazarSil.Click += new System.EventHandler(this.btnYazarSil_Click);
            // 
            // frmYazarSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(492, 342);
            this.Controls.Add(this.btnYazarSil);
            this.Controls.Add(this.lstwYazarlar);
            this.Name = "frmYazarSil";
            this.Text = "frmYazarSil";
            this.Load += new System.EventHandler(this.frmYazarSil_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lstwYazarlar;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnYazarSil;
    }
}