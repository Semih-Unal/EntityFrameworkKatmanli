﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//-------------------------------
using _1_KatmanliMimari.DAL; // MVC'deki > Model kısmına denk geliyor ...
using _2_KatmanliMimari.BLL; // MVC'deki > Controller kısmına denk geliyor ...
using _3_KatmanliMimari.DTO;

namespace _4_KatmanliMimari.UI.Yazar
{
    public partial class frmYazarEkle : Form
    {
        public frmYazarEkle()
        {
            InitializeComponent();
        }

        private void frmYazarEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                // I.yol
                YazarDTO yazar = new YazarDTO()
                {
                    YazarAd = txtYazarAdi.Text,
                    YazarSoyad = txtYazarSoyadi.Text,
                    Ozgecmis = txtOzgecmis.Text
                };
                YazarRepository.YazarEkleme(yazar);

                // II.yol
                //YazarDTO yazar = new YazarDTO()
                //{
                //    YazarAd = txtYazarAdi.Text,
                //    YazarSoyad = txtYazarSoyadi.Text,
                //    Ozgecmis = txtOzgecmis.Text
                //};
                //YazarEkle(yazar);

                //--------------------

                DialogResult dr = MessageBox.Show("Yazar Başarılıyla Eklenmişrir. Yeni Yazar Eklemek İstermisiniz ?","Yazar Ekleme Bildirimi", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    Temizle();
                }
                else
                {
                    Form1 frm = new Form1();
                    this.Close();
                    frm.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Temizle()
        {
            txtYazarAdi.Clear();
            txtYazarSoyadi.Clear();
            txtOzgecmis.Clear();

            txtYazarAdi.Focus();
        }
    }
}
